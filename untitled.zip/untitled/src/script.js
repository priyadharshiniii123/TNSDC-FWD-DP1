document.getElementById('contactForm').addEventListener('submit', function (e) {

  e.preventDefault();

  // Simple form validation

  const name = document.getElementById('name').value.trim();

  const email = document.getElementById('email').value.trim();

  const message = document.getElementById('message').value.trim();

  const status = document.getElementById('formStatus');

  if (!name || !email || !message) {

    status.textContent = "Please fill out all fields.";

    status.style.color = "red";

    return;

  }

  status.textContent = "Thanks for your message, " + name + "!";

  status.style.color = "green";

  // Reset form

  document.getElementById('contactForm').reset();

});